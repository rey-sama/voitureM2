import chemin.BadOrientationExeption;
import chemin.BadRoadException;
import chemin.Point;
import chemin.Route;
import chemin.Rue;


public class Test
{
	public static void main(String[] args)
	{
		//testOrientationRoute();
		//testDist();
		//testCreateRoute();
		System.out.println("A".compareTo("B"));
	}
	
	public static void testCreateRoute()
	{
		int[] x =	 	{	10,	10,	300,300	};
		int[] y = 		{	10,	100,100,10	};
		int[] l = 		{	30,	30,	30,	30	};
		int[] y_false = {	10,	100,100,10,	20};
		int[] y_false2= {	10,	200,100,10	};
		
		Route route=null;
		
		try
		{
			route = new Route(x, y_false, l,0,0, false);
			System.out.println(route);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		try
		{
			route = new Route(x, y_false2, l, 0, 0, false);
			System.out.println(route);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		try
		{
			route = new Route(x, y, l, 0, 0, false);
			System.out.println(route);
			System.out.println("\n\n");
			route.addRue(10, 10, 10, 100, 60, -1);
			System.out.println(route);
			System.out.println("\n\n");
			System.out.println(route.generateProtocol().replace('\t', '\t'));
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		
		
	}
	
	public static void testOrientationRoute()
	{
		try
		{
			Rue r1 = new Rue(-1,10, 10, 10, 20, 0, 1);
			System.out.println(r1.orientation);
			
			Rue r2 = new Rue(-1,10, 10, 20, 10, 0, 1);
			System.out.println(r2.orientation);
			
			Rue r3 = new Rue(-1,10, 10, 20, 20, 0, 1);
			System.out.println(r3.orientation);
		}
		catch(BadOrientationExeption e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	public static void testDist()
	{
		Point p1 = new Point(2, 6);
		Point p2 = new Point(2, 2);
		Point p3 = new Point(5, 2);
		Point p4 = new Point(5, 3);
		Point p5 = new Point(5, -2);
		Point p6 = new Point(5, 11);
		
		Rue r=null;
		Rue r2=null;
		Rue r3=null;
		Rue r4=null;
		Rue r5=null;
		Rue r6=null;
		Rue r7=null;
		try
		{
			r = new Rue(-1,p1, p2, 0, 1);
			r2 = new Rue(-1,5, -2, 5, -5, 0, 1);
			r3 = new Rue(-1,5, 2, 5, -2, 0, 1);
			r4 = new Rue(-1,4, 4, 4, 0, 0, 1);
			r5 = new Rue(-1,3, 5, 10, 5, 0, 1);
			r6 = new Rue(-1,0, 3, 5, 3, 0, 1);
			r7 = new Rue(-1,14, -3, 18, -3, 0, 1);
		}
		catch (BadOrientationExeption e)
		{
			e.printStackTrace();
		}
		
		System.out.println("Distance p1 -> p3 = " +p1.distance(p3) +" : have to be 5");
		
		System.out.println("Distance r -> p3 = " +r.distance(p3) +" : have to be 3");
		
		System.out.println("Distance r -> p4 = " +r.distance(p4) +" : have to be 3");
		
		System.out.println("Distance r -> p5 = " +r.distance(p5) +" : have to be 5");
		
		System.out.println("Distance r -> p6 = " +r.distance(p6) +" : have to be 5");
		
		System.out.println("Distance r -> r2 = " +r.distance(r2) +" : have to be 5");
		
		System.out.println("Distance r -> r3 = " +r.distance(r3) +" : have to be 3");
		
		System.out.println("Distance r -> r4 = " +r.distance(r4) +" : have to be 2");
		
		System.out.println("Distance r -> r5 = " +r.distance(r5) +" : have to be 1");
		
		System.out.println("Distance r5 -> r = " +r5.distance(r) +" : have to be 1");
		
		System.out.println("Distance r -> r6 = " +r.distance(r6) +" : have to be 0");
		
		System.out.println("Distance r6 -> r = " +r6.distance(r) +" : have to be 0");
		
		System.out.println("Distance r -> r7 = " +r.distance(r7) +" : have to be 13");
		
		System.out.println("Distance r7 -> r = " +r7.distance(r) +" : have to be 13");
	}
}
