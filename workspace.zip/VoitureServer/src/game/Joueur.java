package game;

public class Joueur {
	 public long id;
	 public String pseudo;
	 public Voiture car;
	 
	 public void seConnecter()
	 {
	 }
	 
	 

}
