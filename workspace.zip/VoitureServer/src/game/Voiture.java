package game;

import game.bonusMalus.impact.ImpactBonusGiver;
import game.bonusMalus.impact.ImpactBonusMalus;
import game.bonusMalus.object.ChampignonBonus;
import game.bonusMalus.object.ObjetBonusMalus;

import java.util.ArrayList;

import server.Utilisateur;
import chemin.Point;
import chemin.StartLine;

public class Voiture implements Comparable<Voiture>
{
	public static final int ANGLE = 5;
	public static final int DESCELERATION = 5;

	public long id;
	private double x;
	private double y;
	public int acceleration;
	public int frein;
	private int orientation;

	public int vitesseMin;
	public int vitesse;
	public int vitesseMax;

	private double ratio;

	public int jaugeEssenceMax;
	public int jaugeEssence;
	public int diminutionCarburant;
	private ObjetBonusMalus obj;
	public ArrayList<ImpactBonusMalus> listBonusMalus;
	
	private int nbTour;
	private int numRoute;
	private int posRoute;

	private boolean onReparation;
	
	private Utilisateur utilisateur;

	public Voiture(long id, Utilisateur utilisateur, int x, int y, int acceleration, int frein, int vitesseMin, int vitesseMax, int jaugeEssenceMax, int diminutionCarburant)
	{
		super();
		this.id = id;
		this.utilisateur = utilisateur;
		this.x = x;
		this.y = y;
		this.acceleration = acceleration;
		this.frein = frein;
		this.vitesseMin = vitesseMin;
		this.vitesseMax = vitesseMax;
		this.jaugeEssenceMax = jaugeEssenceMax;
		this.diminutionCarburant = diminutionCarburant;

		orientation = 90;
		
		obj = new ChampignonBonus(-1,-1);
		listBonusMalus = new ArrayList<ImpactBonusMalus>();

		this.vitesse = 0;
		this.jaugeEssence = jaugeEssenceMax;

		nbTour=-1;
	}

	public String getObjLabel()
	{
		if(obj==null)
		{
			return "NONE";
		}
		else
		{
			return obj.getLabel();
		}
	}

	public void useObject()
	{
		if(obj!=null)
		{
			obj.use(this);
			obj = null;
		}
	}

	/* liste des fonctions */
	public void tournerGauche()
	{
		orientation-=ANGLE;
	}
	public void tournerDroite()
	{
		orientation+=ANGLE;
	}

	public void rebond()
	{
		vitesse/=-5;
	}



	private boolean deplacement(double anc_x, double anc_y)
	{
		int vitesse = this.vitesse/10;
		x += vitesse*Math.cos(orientation*Math.PI/180);
		y += vitesse*Math.sin(orientation*Math.PI/180);

		ratio = 1;
		onReparation = false;

		ratio = getPartie().map.isOnRoad(this);
		this.affectBonusMalus();
		if(ratio==0)
		{
			x=anc_x;
			y=anc_y;
			this.vitesse/=-5;
			return false;
		}
		else
		{
			StartLine startLine = getPartie().map.getStart();

			if(startLine.getRue().isOnRoad(this)!=0)
			{
				System.out.println(nbTour);
				nbTour += startLine.turn((int)anc_x, (int)anc_y, (int)x, (int)y);
			}
			return true;
		}
	}

	public void avancer()
	{
		double anc_x = x;
		double anc_y = y;


		if(deplacement(anc_x, anc_y))
		{
			if(this.vitesse > vitesseMax * Math.abs(ratio))
			{
				this.vitesse -= DESCELERATION; //Si vitesse max diminuer brusquement
			}
			else
			{
				this.vitesse += acceleration;
			}
		}
	}
	public void reculer()
	{
		double anc_x = x;
		double anc_y = y;

		if(deplacement(anc_x, anc_y))
		{

			if(this.vitesse > 0)
			{
				this.vitesse -= frein;
			}
			else
			{
				if(this.vitesse < vitesseMin * Math.abs(ratio))
				{
					this.vitesse += DESCELERATION; //Si vitesse min augmente brusquement
				}
				else
				{
					this.vitesse -= acceleration;
				}
			}
		}
	}
	public void decelerer()
	{		
		double anc_x = x;
		double anc_y = y;

		if(deplacement(anc_x, anc_y))
		{
			if(this.vitesse>0)
			{
				this.vitesse-=DESCELERATION;
			}
			else if(this.vitesse<0)
			{
				this.vitesse+=DESCELERATION;
			}
		}
	}

	public long getId()
	{
		return id;
	}

	public double getX()
	{
		return x;
	}

	public double getY()
	{
		return y;
	}


	public int getOrientation()
	{
		return orientation;
	}

	public void setX(int x)
	{
		this.x = x;
	}
	public void setY(int y)
	{
		this.y = y;
	}

	public void setOrientation(int orientation)
	{
		this.orientation = orientation;
	}

	public String getInfo()
	{
		return id + ";" + utilisateur.getPseudo() + ";" + (int)x + ";" + (int)y + ";" + orientation;
	}


	public Point getPoint()
	{
		return new Point((int)x, (int)y);
	}

	public void setObj(ObjetBonusMalus obj) {
		this.obj = obj;
	}

	public void affectedBonusMalus(ImpactBonusGiver impactBonusGiver)
	{
		this.listBonusMalus.add(impactBonusGiver);
	}

	public ArrayList<ImpactBonusMalus> getImpact()
	{
		return listBonusMalus;
	}

	public boolean isOnReparation()
	{
		return onReparation;
	}

	public void setOnReparation(boolean onReparation)
	{
		this.onReparation = onReparation;
	}


	private void affectBonusMalus()
	{
		ArrayList<ImpactBonusMalus> aRm = new ArrayList<ImpactBonusMalus>();
		for(ImpactBonusMalus imp : listBonusMalus)
		{
			if(imp.isFinished())
			{
				aRm.add(imp);
			}
			else
			{
				imp.effect(this);
			}
		}
		listBonusMalus.removeAll(aRm);
	}

	public boolean haveAnObject()
	{
		return (obj!=null);
	}

	public int getNbTour() {
		return nbTour;
	}

	public void setNbTour(int nbTour) {
		this.nbTour = nbTour;
	}

	public int getNumRoute() {
		return numRoute;
	}

	public void setNumRoute(int numRoute) {
		this.numRoute = numRoute;
	}

	public int getPosRoute() {
		return posRoute;
	}

	public void setPosRoute(int posRoute) {
		this.posRoute = posRoute;
	}

	public int compareTo(Voiture v)
	{
		if(v.nbTour<this.nbTour)
		{
			return -1;
		}
		else if(this.nbTour<v.nbTour)
		{
			return 1;
		}
		else
		{
			if(v.numRoute<this.numRoute)
			{
				return -1;
			}
			else if(this.numRoute<v.numRoute)
			{
				return 1;
			}
			else
			{
				if(v.posRoute<this.posRoute)
				{
					return -1;
				}
				else if(this.posRoute<v.posRoute)
				{
					return 1;
				}
				else
				{
					return 0;
				}
			}
		}
	}
	
	public Partie getPartie()
	{
		return utilisateur.getPartie();
	}

	public void setVitesse(int i)
	{
		vitesse=i;
	}
}
