package game.bonusMalus.object;

import game.Voiture;
import game.bonusMalus.impact.ImpactBonusGiver;
import game.bonusMalus.impact.ImpactBonusMalus;

import java.util.ArrayList;
import java.util.Random;

public class BonusGiver extends ObjetBonusMalus
{
	public BonusGiver(int x, int y)
	{
		super(x, y);
	}
	
	public void use(Voiture voiture)
	{
		active(voiture);
	}

	public void active(Voiture voiture)
	{
		if(voiture.haveAnObject())
		{
			return;
		}
		
		ArrayList<ImpactBonusMalus> impacts = voiture.getImpact();
		for(ImpactBonusMalus imp : impacts)
		{
			if(imp instanceof ImpactBonusGiver)
			{
				return;
			}
		}
		
		Random rand = new Random();
		int a=rand.nextInt(2);
		if(a==0)
		{
			voiture.setObj(new ChampignonBonus(-1, -1));
		}
		else if(a==1)
		{
			voiture.setObj(new BananaMalus(-1, -1));
		}
		voiture.affectedBonusMalus(new ImpactBonusGiver(1)); 	
	}

	public String getLabel()
	{
		return "GIVER";
	}
	
}
