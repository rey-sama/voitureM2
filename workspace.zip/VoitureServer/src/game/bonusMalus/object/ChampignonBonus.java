package game.bonusMalus.object;

import game.Voiture;

public class ChampignonBonus extends ObjetBonusMalus
{
	
	public ChampignonBonus(int x, int y)
	{
		super(x, y);
	}
	
	public void use(Voiture voiture)
	{
		active(voiture);
	}

	public void active(Voiture voiture)
	{
		voiture.vitesse=300;
	}

	public String getLabel()
	{
		return "CHAMPI";
	}
	
}
