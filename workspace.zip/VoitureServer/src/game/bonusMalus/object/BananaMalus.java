package game.bonusMalus.object;

import game.Voiture;
import server.Server;

public class BananaMalus extends ObjetBonusMalus
{
	
	public BananaMalus(int x, int y)
	{
		super(x, y);
	}
	
	public void use(Voiture voiture)
	{
		this.setX((int) (voiture.getX() -  25*Math.cos(voiture.getOrientation()*Math.PI/180)));
		this.setY((int) (voiture.getY() -  25*Math.sin(voiture.getOrientation()*Math.PI/180)));
		voiture.getPartie().map.addObject(this);
	}

	public void active(Voiture voiture)
	{
		voiture.vitesse=0;
	}

	public String getLabel()
	{
		return "BANANA";
	}
	
}
