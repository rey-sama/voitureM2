package game.bonusMalus.object;

import game.Voiture;
import chemin.Point;

public abstract class ObjetBonusMalus
{
	private int x;
	private int y;
	
	
	public abstract void use(Voiture voiture);
	public abstract void active(Voiture voiture);
	public abstract String getLabel();
	
	public ObjetBonusMalus(int x, int y)
	{
		this.x=x;
		this.y=y;
	}
	
	public int getX()
	{
		return x;
	}
	public void setX(int x)
	{
		this.x = x;
	}

	public int getY()
	{
		return y;
	}
	public void setY(int y)
	{
		this.y = y;
	}
	
	public String protocole()
	{
		String str = getLabel()+";"+x+";"+y+";";
		return str;
	}
	
	public Point getPoint()
	{
		return new Point(x, y);
	}
}
