package game.bonusMalus.impact;

import game.Voiture;

public abstract class ImpactBonusMalus
{
	private int timer;
	
	public ImpactBonusMalus(int timer)
	{
		this.timer = timer*30;
	}
	
	public int effect(Voiture v)
	{
		this.timer --;
		return 0;
	}

	public boolean isFinished()
	{
		System.out.println(timer);
		if(timer==0)
		{
			return true;
		}
		return false;
	}
}
