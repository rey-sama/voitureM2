package game.bonusMalus.impact;

import game.Voiture;

public class ImpactBonusGiver extends ImpactBonusMalus
{
	public ImpactBonusGiver(int timer)
	{
		super(timer);
	}

	public int effect(Voiture v)
	{
		return super.effect(v);
	}
}
