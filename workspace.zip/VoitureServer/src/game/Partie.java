package game;

import game.bonusMalus.object.ObjetBonusMalus;

import java.util.ArrayList;
import java.util.Collections;

import chemin.Point;
import chemin.Route;
import chemin.Rue;
import chemin.StartLine;

public class Partie
{
	public long id;
	private String name;
	public Route map;
	public ArrayList<Voiture> listVoiture;
	public ArrayList<ObjetBonusMalus> listObjet;
	
	private static int IDs=0;
	
	private boolean open;
	
	public Partie(String Name)
	{
		id=IDs;
		name = Name;
		listVoiture = new ArrayList<Voiture>();
		listObjet = new ArrayList<ObjetBonusMalus>();
		map = makeDefaultRoad();
		open = true;
		
		IDs++;
	}
	
	public void addVoiture(Voiture v)
	{
		synchronized(listVoiture)
		{
			listVoiture.add(v);
		}
	}
	
	public ArrayList<Voiture> getListVoiture()
	{
		return listVoiture;
	}
	public void setListVoiture(ArrayList<Voiture> listVoiture)
	{
		this.listVoiture = listVoiture;
	}
	
	private Route makeDefaultRoad()
	{
		Route route=null;

		int t = 2;
		
		int[] x =	 	{	50*t,	50*t,	600*t,  	600*t,	400*t,	400*t,	250*t,	250*t,	400*t,	400*t,	650*t,	650*t,	800*t,	800*t,	950*t,	950*t,	1400*t,	1400*t,	1100*t,	1100*t,	1250*t,	1250*t,	950*t,	950*t,	550*t,	550*t,	350*t,	350*t};
		int[] y = 		{	50*t,	1000*t,  1000*t,	800*t,	800*t,	700*t,	700*t,	550*t,	550*t,	450*t,	450*t,	350*t,	350*t,	750*t,	750*t,	1200*t,	1200*t,	750*t,	750*t,	450*t,	450*t,	250*t,	250*t,	50*t,		50*t,		250*t,	250*t,	50*t};
		int[] l = 		{	80,		80,		80,		80,		80,		80,		80,		80,		80,		80,		80,		80,		80,		80,		80,		80,		80,		80,		80,		80,		80,		80,		80,		80,		80,		80,		80,		80};

		try
		{
			route = new Route(x, y, l, 0, 400, true);
			route.addRue(new Rue(-1, 1200, 2000, 1200, 900, 40, 0.25));
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		System.out.println(route+"\nTest");
		return route;
	}

	public String voitureClassement()
	{
		String str = "";
		synchronized(listVoiture)
		{
			Collections.sort(listVoiture);
		}
		for(Voiture v : listVoiture)
		{
			str+=v.getId();
		}
		return str;
	}

	public String toString()
	{
		String str = "";
		str += id+";"+name+";"+(open ? "OPEN":"CLOSE")+";"+listVoiture.size();
		return str;
	}
	
	public void begin()
	{
		StartLine line = map.getStart();
		Point p = line.getDepartPoint();
		System.out.println(p.getX() + " "  + p.getY());
		for(Voiture v : listVoiture)
		{
			v.setX(p.getX());
			v.setY(p.getY());
			v.setOrientation(line.getOrientation());
			v.setVitesse(0);
		}
		open = false;
	}
	
	public String protocole()
	{
		return toString();
	}

	public boolean isOpen() {
		return open;
	}

	public void setOpen(boolean open) {
		this.open = open;
	}
}
