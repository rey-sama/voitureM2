package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import javax.jws.soap.SOAPBinding.Use;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import game.Partie;
import game.Voiture;
import game.bonusMalus.object.BananaMalus;
import game.bonusMalus.object.ChampignonBonus;
import game.bonusMalus.object.ObjetBonusMalus;
import server.Server;
import server.Utilisateur;

public class GamingServlet extends HttpServlet
{
	private static final long serialVersionUID = -7490197099527975893L;

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		//System.out.println("''"+req.getRequestURL()+"''");
		long id = Long.parseLong(req.getParameter("id"));
		Utilisateur u = Server.getUtilisateur(id);
		Voiture v = u.getVoiture();
		if("1".equals(req.getParameter("gauche")))
		{
			v.tournerGauche();
		}
		else if("1".equals(req.getParameter("droite")))
		{
			v.tournerDroite();
		}

		if("1".equals(req.getParameter("reculer")))
		{
			v.reculer();
		}
		else if("1".equals(req.getParameter("avancer")))
		{
			v.avancer();
		}
		else
		{
			v.decelerer();
		}

		if("1".equals(req.getParameter("useObj")))
		{
			System.out.println(req.getParameter("useObj"));
			if(v.getPartie().isOpen())
			{
				v.getPartie().begin();
			}
			else
			{
				v.useObject();
			}
		}
		System.out.println(v.getId() + " " + v.getNbTour());
		//System.out.println("--------------------\n"+v.getId()+" "+returnAllInfo(v));
		u.getPartie().map.haveAObject(v);
		res.getOutputStream().print(returnAllInfo(v));
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		doGet(req, res);
	}

	public String returnAllInfo(Voiture v)
	{
		Partie p = v.getPartie();
		String str="";
		synchronized(p.getListVoiture())
		{
			Collections.sort(p.getListVoiture());
			str += p.getListVoiture().size()+"\t";
			str+=p.getListVoiture().indexOf(v)+"\t";
			str+=v.getInfo()+"\t";
			for(Voiture vNext : p.getListVoiture())
			{
				if(!(v.equals(vNext)))
				{
					str+=vNext.getInfo()+"\t";
				}
			}
			str+=v.getObjLabel()+"\t"+protocoleObjets(v.getPartie().map.getObjects());
		}
		return str;
	}

	public String protocoleObjets(ArrayList<ObjetBonusMalus> list)
	{
		String str = list.size()+"\t";
		for(ObjetBonusMalus obj : list)
		{
			str+=obj.protocole()+"\t";
		}
		return str;
	}
}
