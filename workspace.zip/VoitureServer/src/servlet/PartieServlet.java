package servlet;

import game.Partie;
import game.Voiture;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import server.Server;
import server.Utilisateur;

public class PartieServlet extends HttpServlet
{
	private static final long serialVersionUID = -7490197099527975893L;
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		String newP = req.getParameter("new");
		
		long id = Long.parseLong(req.getParameter("id"));
		Utilisateur u = Server.getUtilisateur(id);
		Voiture v = u.getVoiture();
		
		if("1".equals(newP))
		{
			Partie partie = new Partie(req.getParameter("name"));
			Server.addPartie(partie);
			partie.addVoiture(v);
			u.setPartie(partie);
			res.getOutputStream().print(u.getInfo()+"\t"+u.getPartie().map.generateProtocol()); //Protocole de r�ponse : 
		}
		else if("1".equals(req.getParameter("connect")))
		{
			for(Partie p : Server.getParties())
			{
				long idP = Long.parseLong(req.getParameter("idPartie"));
				if(p.isOpen() && p.id == idP)
				{
					p.addVoiture(v);
					u.setPartie(p);
					res.getOutputStream().print(u.getInfo()+"\t"+p.map.generateProtocol()); //Protocole de r�ponse : 
					return;
				}
			}
			res.getOutputStream().print("NONE"); //Protocole de r�ponse : 
		}
		else if("1".equals(req.getParameter("list")))
		{
			res.getOutputStream().print(protocolePartie()); //Protocole de r�ponse :
		}
		else
		{
			System.out.println("NONE");
		}
		System.out.println("Partie : " + protocolePartie());
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		doGet(req, res);
	}
	
	public String protocolePartie()
	{
		String str = "";
		for(Partie p : Server.getParties())
		{
			str += p.toString()+"\t";
		}
		return str;
	}
}
