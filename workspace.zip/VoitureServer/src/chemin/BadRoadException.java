package chemin;

public class BadRoadException extends Exception
{
}
