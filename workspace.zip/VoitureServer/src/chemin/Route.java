package chemin;

import game.Voiture;
import game.bonusMalus.object.BonusGiver;
import game.bonusMalus.object.ObjetBonusMalus;

import java.util.ArrayList;


public class Route
{
	private ArrayList<Rue> routePrincipale;
	private ArrayList<Rue> autreRue;
	private ArrayList<ObjetBonusMalus> objects;

	private StartLine start;

	public Route(int[] x, int[] y, int[] l, int indexStartRue, int startLine, boolean sens) throws BadRoadException, BadOrientationExeption
	{
		routePrincipale = new ArrayList<Rue>();
		autreRue = new ArrayList<Rue>();
		objects = new ArrayList<ObjetBonusMalus>();

		objects.add(new BonusGiver(100, 600));

		if((x.length!= y.length) || (x.length != l.length))
		{
			throw new BadRoadException();
		}

		for(int i = 0; i < x.length;i++)
		{
			Rue r = new Rue(i,x[i], y[i], x[(i+1)%x.length], y[(i+1)%x.length], l[i], 1);
			routePrincipale.add(r);
		}

		start = new StartLine(routePrincipale.get(indexStartRue), startLine, sens);
	}

	public void addObject(ObjetBonusMalus obj)
	{
		objects.add(obj);
	}

	public void addRue(Rue r)
	{
		autreRue.add(r);
	}

	public void addRue(int x1, int y1, int x2, int y2, int taille, double ratioVitesse) throws BadOrientationExeption
	{
		addRue(new Rue(-1, x1, y1, x2, y2, taille, ratioVitesse));
	}

	public String toString()
	{
		String str = "";
		for(Rue rue : routePrincipale )
		{
			str+=rue+"\n";
		}
		for(Rue rue : autreRue )
		{
			str+=rue+"\n";
		}

		return str;
	}

	public double isOnRoad(Voiture v)
	{
		int coef=1;
		double ratio=0;

		int index = -1;

		for(Rue r : routePrincipale)
		{
			double val = r.isOnRoad(v);
			if(val<0)
			{
				coef=-1;
				val*=-1;
			}

			if(val>ratio)
			{
				ratio = val;
			}
			if(val!=0)
			{
				int indexRue = r.getIndexOnRoute();
				if((indexRue > index) || ((indexRue==0)&&(index==routePrincipale.size()-1 ) ) );
				{
					index = r.getIndexOnRoute();
					if(r.orientation == Rue.HORIZONTAL)
					{
						v.setPosRoute(Math.abs((int)v.getX()-r.getP1().getX()));
					}
					else
					{
						v.setPosRoute(Math.abs((int)v.getY()-r.getP1().getY()));
					}
				}
			}
		}
		for(Rue r : autreRue)
		{
			double val = r.isOnRoad(v);
			if(val<0)
			{
				coef=-1;
				val*=-1;
				v.setOnReparation(true);
			}
			if(val>ratio)
			{
				ratio = val;
			}
		}
		
		if(index != -1)
		{
			v.setNumRoute(index);
		}
		return coef*ratio;
	}

	public void haveAObject(Voiture v)
	{
		ArrayList<ObjetBonusMalus> aRm = new ArrayList<ObjetBonusMalus>();
		for(ObjetBonusMalus obj : objects)
		{
			if(obj.getPoint().distance(v.getPoint())<20)
			{
				obj.active(v);
				if(!(obj instanceof BonusGiver))
				{
					aRm.add(obj);
				}
			}
		}
		objects.removeAll(aRm);
	}

	public String generateProtocol()
	{
		Rue rueDepart = start.getRue();
		String str = "";
		System.out.println(str);
		if(rueDepart.orientation == Rue.HORIZONTAL)
		{
			str+= start.getPos() + ";" + (rueDepart.getP1().getY()-rueDepart.getTaille())+";"+start.getPos() + ";" + (rueDepart.getP1().getY() + ";" + rueDepart.getTaille());
		}
		else
		{
			str+= (rueDepart.getP1().getX()-rueDepart.getTaille())+";"+start.getPos() + ";" + (rueDepart.getP1().getX()+rueDepart.getTaille()) + ";" + start.getPos() ;
		}
		System.out.println("Sa donnera sa : "+str);
		str += "\t"+Integer.toString(routePrincipale.size()+autreRue.size());
		String type="";
		String x1="";
		String y1="";
		String x2="";
		String y2="";
		String taille="";
		
		
		
		for(Rue rue : routePrincipale )
		{
			double t = rue.getRatioVitesse();
			if(t==1)
			{
				type+="RUE;";
			}
			else if(t==-1)
			{
				type+="CARBURANT;";
			}
			else if(t>1)
			{
				type+="BOOST;";
			}
			else
			{
				type+="BOUE;";
			}
			x1+=rue.getP1().getX()+";";
			x2+=rue.getP2().getX()+";";
			y1+=rue.getP1().getY()+";";
			y2+=rue.getP2().getY()+";";
			taille+=rue.getTaille()+";";
		}
		for(Rue rue : autreRue )
		{
			double t = rue.getRatioVitesse();
			if(t==1)
			{
				type+="RUE;";
			}
			else if(t<0)
			{
				type+="CARBURANT;";
			}
			else if(t>1)
			{
				type+="BOOST;";
			}
			else
			{
				type+="BOUE;";
			}
			x1+=rue.getP1().getX()+";";
			x2+=rue.getP2().getX()+";";
			y1+=rue.getP1().getY()+";";
			y2+=rue.getP2().getY()+";";
			taille+=rue.getTaille()+";";
		}
		return str+"\t"+type+"\t"+x1+"\t"+x2+"\t"+y1+"\t"+y2+"\t"+taille;
		
		
	}


	public ArrayList<ObjetBonusMalus> getObjects()
	{
		return objects;
	}

	public StartLine getStart() {
		return start;
	}

}
