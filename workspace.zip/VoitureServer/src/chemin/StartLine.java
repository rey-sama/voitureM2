package chemin;

public class StartLine
{
	private Rue rue;
	
	private int pos;
	private boolean sens;
	
	public StartLine(Rue rue, int pos, boolean sens)
	{
		super();
		this.rue = rue;
		this.pos = pos;
		this.sens = sens;
	}
	
	public int turn(int anc_x, int anc_y, int x, int y)
	{
		if(rue.orientation == Rue.HORIZONTAL)
		{
			if( ((anc_x - pos) * (x-pos) <= 0) && (anc_x != x) && (anc_x != pos))//Sa vérifie si la pos est entre ancienne et la nouvelle position de la voiture
			{
				System.out.println(anc_x + " " + x);
				if(((x-pos) > 0) == sens)		//Va vérifie si c'est dans le bon sens
				{
					return 1;
				}
				else
				{
					return -1;
				}
			}
			else
			{
				return 0;
			}
		}
		else
		{
			if(( (anc_y - pos) * (y-pos) <= 0) && (anc_y != y) && (anc_y != pos))//Sa vérifie si la pos est entre ancienne et la nouvelle position de la voiture
			{
				System.out.println(anc_y + " " + y);
				if(( (y-pos) > 0) == sens)		//Va vérifie si c'est dans le bon sens
				{
					return 1;
				}
				else
				{
					return -1;
				}
			}
			else
			{
				return 0;
			}
		}
	}
	
	public Rue getRue()
	{
		return rue;
	}

	public Point getDepartPoint()
	{
		if(rue.orientation == Rue.HORIZONTAL)
		{
			return new Point(pos, rue.getP1().getY());
		}
		else
		{
			return new Point(rue.getP1().getX(), pos);
		}
	}
	
	public int getOrientation()
	{
		if(rue.orientation == Rue.HORIZONTAL)
		{
			if(sens)
			{
				return 0;
			}
			else
			{
				return 180;
			}
		}
		else
		{
			if(sens)
			{
				return 90;
			}
			else
			{
				return 270;
			}
		}
	}

	public int getPos() {
		return pos;
	}

	public void setPos(int pos) {
		this.pos = pos;
	}
}
