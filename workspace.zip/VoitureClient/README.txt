Infos divers :

	Protocole d'échange des positions
	
	<MyObjId>
	<MyFuel>
	<nbVoiture>
	<voitureClientID><voitureClientX><voitureClientY><voitureClientOrientation>
	<voiture-1-ID><voiture-1-X><voiture-1-Y><voiture-1-Orientation>
	<voiture-2-ID><voiture-2-X><voiture-2-Y><voiture-2-Orientation>
	....
	<voiture-nbVoiture-ID><voiture-nbVoiture-X><voiture-nbVoiture-Y><voiture-nbVoiture-Orientation>
	<nbObjet>
	<ob-1-Type><ob-1-X><ob-1-Y>
	<ob-2-Type><ob-2-X><ob-2-Y>
	....
	<ob-nbObjet-Type><ob-nbObjet-X><ob-nbObjet-Y>
	
	Protocole d'échange des routes
	
	<ID>
	<nbRue>
	<Rue-1-Type1><Rue-1-Point1.x><Rue-1-Point1.y><Rue-1-Point2.x><Rue-1-Point2.y>
	<Rue-2-Type1><Rue-2-Point1.x><Rue-2-Point1.y><Rue-2-Point2.x><Rue-2-Point2.y>
	....
	<Rue-nbRue-Type1><Rue-nbRue-Point1.x><Rue-nbRue-Point1.y><Rue-nbRue-Point2.x><Rue-nbRue-Point2.y>
	
----------------------------------------------------------------