package client;



public class testToken {

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		String test = "4\n1;100;200;0\n2;400;400;180\n1;100;200;0\n2;400;400;180\n";
		//FenetreClient.update(test);
	}

}
